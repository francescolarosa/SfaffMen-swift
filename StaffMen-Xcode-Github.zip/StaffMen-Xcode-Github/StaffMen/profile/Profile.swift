//
//  Profile.swift
//  StaffMen
//
//  Created by la rosa francesco  on 24/05/18.
//  Copyright © 2018 Andrex. All rights reserved.
//

//import Foundation
//
//struct ProfileInfo {
//   
//    var profile1 : String
//}
